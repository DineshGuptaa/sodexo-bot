package pt.bayonne.sensei.multipartdownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipartDownloadApplicationTests {

    @Test
    void contextLoads() {
    }

}

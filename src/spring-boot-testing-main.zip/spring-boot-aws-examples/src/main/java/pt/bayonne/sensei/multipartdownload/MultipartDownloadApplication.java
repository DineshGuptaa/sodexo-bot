package pt.bayonne.sensei.multipartdownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipartDownloadApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipartDownloadApplication.class, args);
    }

}

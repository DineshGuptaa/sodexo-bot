package pt.bayonne.sensei.multipartdownload.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import pt.bayonne.sensei.multipartdownload.domain.SalesInfo;
import pt.bayonne.sensei.multipartdownload.dto.SalesDTO;

@Mapper(componentModel = "spring", unmappedSourcePolicy = ReportingPolicy.ERROR )
public interface SalesMapper {

    SalesInfo mapToEntity(SalesDTO salesDTO);
}

package com.example.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt.reqres.CryptoRequest;
import com.example.jwt.reqres.CryptoResponse;
import com.example.jwt.service.EncryptionService;

import lombok.NonNull;

@RestController
@RequestMapping("/api/crypto")
public class CryptoController {
    private final String SUCCESS = "success"; 
    private final String FAILURE = "failure";
    @Autowired
    private EncryptionService encryptionService;

    @PostMapping("/encrypt")
    public CryptoResponse encryptData(@RequestBody @NonNull CryptoRequest request) throws Exception {

        String encrypted = encryptionService.encrypt(request.profileId());
        return new CryptoResponse(encrypted,SUCCESS); 
    }

    @PostMapping("/decrypt")
    public CryptoResponse decryptData(@RequestBody @NonNull CryptoRequest request,
        @RequestHeader("X-Profile-ID") String currentProfileId) throws Exception {
            
            String decrypted = encryptionService.decrypt(request.jwtString(), currentProfileId);
            if (null != decrypted) {
                return new CryptoResponse(decrypted,SUCCESS);
            }else{
                return new CryptoResponse("Unauthorized: This data does not belong to you.",FAILURE);
            }
    }
}
package com.example.jwt.reqres;

public record CryptoRequest(String jwtString, String profileId) {}

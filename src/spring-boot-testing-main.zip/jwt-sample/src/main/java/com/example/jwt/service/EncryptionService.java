package com.example.jwt.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jwt.util.JwtCryptoConfig;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EncryptionService {

    @Autowired
    JwtCryptoConfig jwtCryptoConfig;


    public String encryptAndCache(String data) throws Exception {
        // 1. Encrypt using this.publicKey
        // 2. Generate UUID
        // 3. Put in cryptoCache
        return null;
    }
    public String encrypt(String profileId) throws Exception {
        // 1. Define the claims (User can't see these once encrypted)
        log.info("Profile Id for JWT:"+profileId);

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject("user123")
                .claim("profile_id", profileId)
                .issuer("https://your-game-system.com")
                .expirationTime(new Date(new Date().getTime() + 1000 * 60 * 15)) // 15 mins
                .build();

        // 2. Set Header: RSA-OAEP-256 for key encryption, AES-GCM for content
        JWEHeader header = new JWEHeader(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM);

        // 3. Create EncryptedJWT object and encrypt it
        EncryptedJWT jwt = new EncryptedJWT(header, claimsSet);

        jwt.encrypt(new RSAEncrypter(jwtCryptoConfig.rsaPublicKey()));

        // 4. Serialize to compact string
        return jwt.serialize();
    }

    public String decrypt(String jwtString, String currentProfileId) throws Exception {
        log.info("Profile Id for Decpryt JWT Token:"+currentProfileId);
        // 1. Parse the string
        EncryptedJWT jwt = EncryptedJWT.parse(jwtString);

        // 2. Decrypt using the private key
        RSADecrypter decrypter = new RSADecrypter(jwtCryptoConfig.rsaPrivateKey());
        jwt.decrypt(decrypter);

        Object profileIdInJwt = jwt.getJWTClaimsSet().getClaim("profile_id");

        // VALIDATION: Check if the caller matches the owner of the encrypted data
        if (profileIdInJwt == null || !profileIdInJwt.equals(currentProfileId)) {
            return null;
        }
        // 3. Access the claims
        log.info("Profile ID: " + profileIdInJwt.toString());
        return profileIdInJwt.toString();
    }
}

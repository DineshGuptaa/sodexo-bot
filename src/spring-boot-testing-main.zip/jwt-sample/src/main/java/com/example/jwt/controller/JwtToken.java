package com.example.jwt.controller;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt.service.EncryptionService;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/vi/")
public class JwtToken {

    @Autowired
    EncryptionService encryptionService ;

    public String createEncryptedToken(RSAPublicKey publicKey, String profileId) throws Exception {
        // 1. Define the claims (User can't see these once encrypted)
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject("user123")
                .claim("profile_id", profileId)
                .issuer("https://your-game-system.com")
                .expirationTime(new Date(new Date().getTime() + 1000 * 60 * 15)) // 15 mins
                .build();

        // 2. Set Header: RSA-OAEP-256 for key encryption, AES-GCM for content
        // encryption
        JWEHeader header = new JWEHeader(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM);

        // 3. Create EncryptedJWT object and encrypt it
        EncryptedJWT jwt = new EncryptedJWT(header, claimsSet);
        jwt.encrypt(new RSAEncrypter(publicKey));

        // 4. Serialize to compact string
        return jwt.serialize();
    }

    public void decryptToken(String jwtString, RSAPrivateKey privateKey) throws Exception {
        // 1. Parse the string
        EncryptedJWT jwt = EncryptedJWT.parse(jwtString);

        // 2. Decrypt using the private key
        RSADecrypter decrypter = new RSADecrypter(privateKey);
        jwt.decrypt(decrypter);

        // 3. Access the claims
        System.out.println("Profile ID: " + jwt.getJWTClaimsSet().getClaim("profile_id"));
    }

}

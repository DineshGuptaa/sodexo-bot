package com.example.jwt.util;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JwtCryptoConfig {


    @Value("${rsa.public-key}")
    private String publicKeyStr;

    @Value("${rsa.private-key}")
    private String privateKeyStr;

    @Bean
    public RSAPublicKey rsaPublicKey() throws Exception {
        return RSAKeyUtil.getPublicKeyFromString(publicKeyStr);
    }

    @Bean
    public RSAPrivateKey rsaPrivateKey() throws Exception {
        return RSAKeyUtil.getPrivateKeyFromString(privateKeyStr);
    }
    
}


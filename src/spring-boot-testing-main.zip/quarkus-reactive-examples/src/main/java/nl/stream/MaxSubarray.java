package nl.stream;

//Solve Maximum Subarray In Single Loop
public class MaxSubarray {

    private static int maxSubArray(int[] array){
        int currentSum = array[0];
        int maxSum = array[0];
        for(int n = 1; n < array.length; n++){
            currentSum = Math.max(array[n], currentSum + array[n]);
            maxSum = Math.max(maxSum, currentSum);
        }    
        return maxSum;
    }
    public static void main(String[] args) {
        int[] nums = {4, -6, 3, 2};
        System.out.println("MaxSubarray.main :"+ maxSubArray(nums));
    }
        
}

package nl.stream;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WordCount {
    //String = "apple banana apple  orange banana"
    //output: {apple=2, banana=2, orange=1}
    public static void main(String[] args) {
        String str = "apple banana apple orange banana";

       Map<String, Long> map = Arrays.stream(str.split(" ")).collect(Collectors.groupingBy(Function.identity(),
                        Collectors.counting()));
        System.out.println(map);
    }
}

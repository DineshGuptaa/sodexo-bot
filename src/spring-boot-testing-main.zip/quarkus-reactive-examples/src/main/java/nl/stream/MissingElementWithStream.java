package nl.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MissingElementWithStream {
    public static void main(String[] args) {
        int[] numbers = {2,3,3,3,4,4,5,7,8,9,1};

        Set<Integer> numberSet = Arrays.stream(numbers)
                .boxed()
                .collect(Collectors.toSet());
        List<Integer> list = IntStream.range(1, 9)
                    .filter(i -> !numberSet.contains(i))
                    .boxed().toList();

        list.forEach(System.out::println);
    }

    
}

package nl.stream;

import java.util.*;
import java.util.function.Function;
import java.util.stream.*;

public class BigramFrequency {
    public static void main(String[] args) {

        String paragraph = "Java is great and Java is fun. Java is powerful!";
        // remove puncuation 
        String[] words = paragraph.toLowerCase().
                replaceAll("[^a-z\\s]", "")
                .split(" ");

        Arrays.stream(words).forEach(word -> System.out.print(word + " "));
        List<String> list = IntStream.range(0, words.length - 1)
                .mapToObj(i -> words[i] + " " + words[i + 1])
                .toList();
        System.out.println("\n"+list);
        
        Map<String, Long> map = list.stream()
                .collect(Collectors.groupingBy(
                        Function.identity(),
                        Collectors.counting()
                ));
        System.out.println(map);
    }
}
package com.automation.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
    features = "src/test/resources/features",
    glue = {
        "com.automation.stepdefs",
        "com.automation.hooks"
    },
    plugin = {
        "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
    }
)

public class TestRunner extends AbstractTestNGCucumberTests {
    

   /* @DataProvider
    public Object[][] scenarios() {
        List<String> sheets = ExcelReader.getExecutableSheets();
        return sheets.stream()
                .map(sheet -> new Object[]{sheet})
                .toArray(Object[][]::new);
    } */
}
package com.automation.stepdefs;

import static io.restassured.RestAssured.given;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automation.config.EnvironmentManager;
import com.automation.excel.ExcelReader;
import com.automation.utils.HeaderUtil;

import io.cucumber.java.en.Given;
import io.restassured.response.Response;

public class ApiStepDefinitions {

    private static final Logger logger = LoggerFactory.getLogger(ApiStepDefinitions.class);


    @Given("I execute all active API sheets")
    public void i_execute_all_active_api_sheets() {
        String baseUrl = EnvironmentManager.getBaseUrl();
        List<String> activeSheets = ExcelReader.getExecutableSheets();

        boolean hasFailure = false;

        for (String sheetName : activeSheets) {
            List<Map<String, String>> testCases = ExcelReader.getTestData(sheetName);

            for (Map<String, String> tc : testCases) {

                if (!"Y".equalsIgnoreCase(tc.get("Execute"))) {
                    continue;
                }

                try {

                    Response response = given()
                            .baseUri(baseUrl)
                            .headers(HeaderUtil.parseHeaders(tc.get("Headers")))
                            .body(tc.get("Body"))
                            .when()
                            .request(tc.get("Method"), tc.get("Endpoint"));

                    int expected = Integer.parseInt(tc.get("ExpectedStatus"));
                    int actual = response.getStatusCode();

                    if (actual != expected) {
                        hasFailure = true;

                        logger.info(
                                "❌ FAILED | Sheet=" + sheetName +
                                        " | Scenario=" + tc.get("Scenario") +
                                        " | Expected=" + expected +
                                        " | Actual=" + actual);
                    } else {
                        logger.info(
                                "✅ PASSED | Sheet=" + sheetName +
                                        " | Scenario=" + tc.get("Scenario"));
                    }

                } catch (Exception e) {
                    hasFailure = true;

                    logger.error(
                            "❌ ERROR | Sheet=" + sheetName +
                                    " | Scenario=" + tc.get("Scenario") +
                                    " | Message=" + e.getMessage());
                }
            }
        }

        // ✅ Optional: fail build AFTER all tests
        if (hasFailure) {
            throw new AssertionError("Some API test cases failed. Check logs.");
        }
    }
}
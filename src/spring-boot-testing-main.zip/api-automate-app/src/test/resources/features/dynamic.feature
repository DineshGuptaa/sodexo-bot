Feature: API automation via Excel

  Scenario Outline: Execute API test cases from Excel
    Given I execute all active API sheets
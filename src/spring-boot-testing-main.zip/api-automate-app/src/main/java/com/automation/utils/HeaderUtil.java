package com.automation.utils;

import java.util.HashMap;
import java.util.Map;

public class HeaderUtil {

    public static Map<String, String> parseHeaders(String headerString) {

        Map<String, String> headers = new HashMap<>();

        if (headerString == null || headerString.trim().isEmpty()) {
            return headers;
        }

        String[] pairs = headerString.split(",");

        for (String pair : pairs) {
            String[] keyValue = pair.split(":", 2);
            headers.put(keyValue[0].trim(), keyValue[1].trim());
        }

        return headers;
    }
}

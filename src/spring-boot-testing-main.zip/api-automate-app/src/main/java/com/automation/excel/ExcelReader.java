package com.automation.excel;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

    private static Workbook workbook;

    static {
        try {
            FileInputStream fis = new FileInputStream("src/test/resources/testdata/ApiTestCases.xlsx");
            workbook = new XSSFWorkbook(fis);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static List<String> getExecutableSheets() {
        Sheet sheet = workbook.getSheet("ExecutionControl");
        List<String> executableSheets = new ArrayList<>();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            if (sheet.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase("Y")) {
                executableSheets.add(sheet.getRow(i).getCell(0).getStringCellValue());
            }
        }
        return executableSheets;
    }

    public static List<Map<String, String>> getTestData(String sheetName) {
        Sheet sheet = workbook.getSheet(sheetName);
        Row header = sheet.getRow(0);

        List<Map<String, String>> data = new ArrayList<>();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Map<String, String> rowData = new HashMap<>();
            Row row = sheet.getRow(i);

            for (int j = 0; j < header.getLastCellNum(); j++) {
                rowData.put(header.getCell(j).getStringCellValue(),
                        row.getCell(j).getStringCellValue());
            }
            data.add(rowData);
        }
        return data;
    }

    public static String getEnvironmentUrl(String env) {

        Sheet sheet = workbook.getSheet("Environment");

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String envName = row.getCell(0).getStringCellValue();

            if (envName.equalsIgnoreCase(env)) {
                return row.getCell(1).getStringCellValue();
            }
        }
        throw new RuntimeException("Environment not found in Excel: " + env);
    }

}

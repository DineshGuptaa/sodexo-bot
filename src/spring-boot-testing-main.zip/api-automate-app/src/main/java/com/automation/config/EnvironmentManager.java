package com.automation.config;

import com.automation.excel.ExcelReader;

public class EnvironmentManager {

    public static String getBaseUrl() {
        String env = System.getProperty("env", "DEV");
        return ExcelReader.getEnvironmentUrl(env);
    }
}

package sample;// PayloadExtractor.java
// Usage:
//   javac PayloadExtractor.java
//   java PayloadExtractor <input_path> <output_csv>
//
// Description:
//   Reads a Mule log file or a directory of log files, extracts JSON payloads
//   following "PAYLOAD::", captures the line number where each payload occurs,
//   and parses two fields from the JSON: tracking_no and is_return_delivery.
//   Outputs a single CSV with columns:
//     line_number,tracking_no,is_return_delivery,payload,source_file
//
//   - If <input_path> is a directory, all regular files inside it are processed.
//   - No external dependencies.
//
//   Date: 2025-12-29

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class PayloadExtractor {
    private static final Charset CHARSET = StandardCharsets.UTF_8;

    // Capture JSON between PAYLOAD:: and Bearer token
    private static final Pattern PAYLOAD_PATTERN = Pattern.compile(
            "PAYLOAD::\\s*(\\{.*?\\})\\s*Bearer", Pattern.DOTALL);

    // Fallback: PAYLOAD:: { ... } to end of line if Bearer is absent
    private static final Pattern PAYLOAD_TO_EOL_PATTERN = Pattern.compile(
            "PAYLOAD::\\s*(\\{.*?\\})\\s*$", Pattern.DOTALL | Pattern.MULTILINE);

    // Extractors for fields from JSON payload (no external JSON library)
    private static final Pattern TRACKING_NO_PATTERN = Pattern.compile(
            "\\\"tracking_no\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");

    private static final Pattern IS_RETURN_DELIVERY_PATTERN = Pattern.compile(
            "\\\"is_return_delivery\\\"\\s*:\\s*(true|false|null|\\\"[^\\\"]*\\\")", Pattern.CASE_INSENSITIVE);

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java PayloadExtractor <input_path> <output_csv>");
            System.exit(1);
        }

        File inputPath = new File(args[0]);
        String csvOut = args[1];

        if (!inputPath.exists()) {
            System.err.println("Error: input path not found: " + inputPath.getAbsolutePath());
            System.exit(2);
        }

        List<File> filesToProcess = new ArrayList<>();
        if (inputPath.isDirectory()) {
            File[] children = inputPath.listFiles();
            if (children != null) {
                for (File f : children) {
                    if (f.isFile()) {
                        filesToProcess.add(f);
                    }
                }
            }
            if (filesToProcess.isEmpty()) {
                System.err.println("No files found in directory: " + inputPath.getAbsolutePath());
                System.exit(3);
            }
        } else if (inputPath.isFile()) {
            filesToProcess.add(inputPath);
        } else {
            System.err.println("Input path is neither file nor directory: " + inputPath.getAbsolutePath());
            System.exit(4);
        }
        if(null != csvOut && (!csvOut.startsWith("C:") || !csvOut.startsWith("c:"))){
            csvOut = "C:\\Users\\Dinesh.Gupta\\Downloads\\"+csvOut;
        }else{
            System.err.println("No Output files specified: " + inputPath.getAbsolutePath());
            System.exit(5);
        }
        int totalHits = 0;
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(csvOut, false))) {
            // CSV header
            bw.write("line_number,tracking_no,is_return_delivery,payload,source_file");
            bw.newLine();

            for (File file : filesToProcess) {
                try {
                    String content = readWholeFile(file);
                    List<PayloadHit> hits = extractPayloadsWithLine(content);
                    for (PayloadHit hit : hits) {
                        String trackingNo = extractTrackingNo(hit.payload);
                        String isReturn   = extractIsReturnDelivery(hit.payload);

                        String lineNumberStr = Integer.toString(hit.lineNumber);
                        String trackingEsc   = csvEscape(trackingNo);
                        String isReturnEsc   = csvEscape(isReturn);
                        String payloadEsc    = csvEscape(hit.payload);
                        String sourceEsc     = csvEscape(file.getAbsolutePath());

                        bw.write(lineNumberStr + "," + trackingEsc + "," + isReturnEsc + "," + payloadEsc + "," + sourceEsc);
                        bw.newLine();
                        totalHits++;
                    }
                } catch (IOException e) {
                    System.err.println("Skipping file due to I/O error: " + file.getAbsolutePath() + " -> " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("I/O error writing CSV: " + e.getMessage());
            System.exit(5);
        }

        System.out.println("CSV: " + totalHits + " payload(s) across " + filesToProcess.size() + " file(s) -> " + csvOut);
    }

    private static String readWholeFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder(Math.max(8192, (int) Math.min(f.length(), Integer.MAX_VALUE)));
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), CHARSET))) {
            char[] buf = new char[8192];
            int r;
            while ((r = br.read(buf)) != -1) {
                sb.append(buf, 0, r);
            }
        }
        return sb.toString();
    }

    private static List<PayloadHit> extractPayloadsWithLine(String content) {
        List<PayloadHit> results = new ArrayList<>();

        // Precompute line starts for quick index->line mapping
        List<Integer> lineStarts = new ArrayList<>();
        lineStarts.add(0);
        for (int i = 0; i < content.length(); i++) {
            if (content.charAt(i) == '\n') {
                lineStarts.add(i + 1);
            }
        }

        Matcher m = PAYLOAD_PATTERN.matcher(content);
        while (m.find()) {
            int start = m.start();
            int lineNo = indexToLineNumber(start, lineStarts);
            String json = sanitizeWhitespace(m.group(1));
            results.add(new PayloadHit(lineNo, json));
        }

        Matcher m2 = PAYLOAD_TO_EOL_PATTERN.matcher(content);
        while (m2.find()) {
            int start = m2.start();
            int lineNo = indexToLineNumber(start, lineStarts);
            String candidate = sanitizeWhitespace(m2.group(1));
            if (!containsPayload(results, candidate)) {
                results.add(new PayloadHit(lineNo, candidate));
            }
        }
        return results;
    }

    private static boolean containsPayload(List<PayloadHit> hits, String payload) {
        for (PayloadHit h : hits) {
            if (h.payload.equals(payload)) return true;
        }
        return false;
    }

    private static int indexToLineNumber(int index, List<Integer> lineStarts) {
        int lo = 0, hi = lineStarts.size() - 1, ans = 0;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int v = lineStarts.get(mid);
            if (v <= index) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
        }
        return ans + 1; // 1-based
    }

    private static String sanitizeWhitespace(String s) {
        String t = s.trim();
        t = t.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
        t = t.replaceAll("\\s{2,}", " ");
        return t;
    }

    private static String extractTrackingNo(String json) {
        Matcher m = TRACKING_NO_PATTERN.matcher(json);
        if (m.find()) return m.group(1);
        return ""; // empty if missing
    }

    private static String extractIsReturnDelivery(String json) {
        Matcher m = IS_RETURN_DELIVERY_PATTERN.matcher(json);
        if (m.find()) {
            String raw = m.group(1).trim();
            if (raw.equalsIgnoreCase("true") || raw.equalsIgnoreCase("false")) {
                return raw.toLowerCase();
            }
            if (raw.equalsIgnoreCase("null")) return ""; // empty for null
            // quoted string value: strip quotes
            if (raw.startsWith("\"") && raw.endsWith("\"")) {
                return raw.substring(1, raw.length() - 1);
            }
            return raw; // fallback
        }
        return "";
    }

    private static String csvEscape(String s) {
        // Wrap in quotes and escape inner quotes
        String esc = s.replace("\"", "\"\"");
        return '"' + esc + '"';
    }

    private static class PayloadHit {
        final int lineNumber;
        final String payload;
        PayloadHit(int lineNumber, String payload) {
            this.lineNumber = lineNumber;
            this.payload = payload;
        }
    }
}

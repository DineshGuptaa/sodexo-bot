package com.saml;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class TopPricesByVolueSabre {
    public static void main(String[] args) {
        Map<Double, Double> priceVolumeMap = new HashMap<>();
        priceVolumeMap.put(100.0, 500.0);
        priceVolumeMap.put(150.0, 300.0);
        priceVolumeMap.put(200.0, 700.0);
        priceVolumeMap.put(250.0, 200.0);   
        System.out.println("Original Map: " + priceVolumeMap);
        Map<Double, Double> top10 = top10PriceByVolume(priceVolumeMap);
        System.out.println("Top 10 Prices by Volume: " + top10);
    }
        
    
    public static Map<Double,Double> top10PriceByVolume(Map<Double , Double> priceVolumeMap) {
        
        Map<Double,Double> map =  priceVolumeMap.entrySet()
                    .stream()
            // STEP 1: sort by Volume (descending)
                    .sorted(Map.Entry.<Double, Double>comparingByValue().reversed())

            // STEP 2: take top 10 by Volume
                    .limit(2)

        // STEP 3: sort those 10 by Price (descending)
                .sorted(Map.Entry.<Double, Double>comparingByKey().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, 
                                Map.Entry::getValue,(a,b)->a, LinkedHashMap::new));
        return map;

    }
}

package com.saml.authentication;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
import org.springframework.stereotype.Service;

@Service
public class SAMLUserDetailsServiceImpl implements AuthenticationUserDetailsService<Saml2Authentication> {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(SAMLUserDetailsServiceImpl.class);

    @Override
    public UserDetails loadUserDetails(Saml2Authentication authentication)
            throws UsernameNotFoundException {

        // Extract username from Saml2Authentication
        String userID = authentication.getName();

        LOG.info(userID + " is logged in");
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

        // Return a simple UserDetails. Password is not used for SAML-based auth.
        return new User(userID, "", authorities);
    }

}
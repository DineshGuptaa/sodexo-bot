package com.saml.config;

import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.saml2.core.Saml2X509Credential;
import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
import org.springframework.security.saml2.provider.service.registration.InMemoryRelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrations;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;

import com.saml.authentication.SAMLUserDetailsServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
public class SamlSecurityConfig {

    @Value("${saml.keystore.path}")
    private String samlKeystorePath;

    @Value("${saml.keystore.password}")
    private String samlKeystorePassword;

    @Value("${saml.keystore.alias}")
    private String samlKeystoreAlias;

    @Value("${saml.url.descriptor}")
    private String samlMetadataUrl;

    @Value("${saml.sp.entity-id:}")
    private String spEntityId;

    @Value("${saml.sp.acs:}")
    private String spAcsUrl;

    @Autowired
    private SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl;

    private Saml2X509Credential loadSigningCredential() {
        try {
            DefaultResourceLoader loader = new DefaultResourceLoader();
            Resource res = loader.getResource(samlKeystorePath);
            try (InputStream is = res.getInputStream()) {
                KeyStore ks = KeyStore.getInstance("JKS");
                ks.load(is, samlKeystorePassword.toCharArray());
                PrivateKey privateKey = (PrivateKey) ks.getKey(samlKeystoreAlias, samlKeystorePassword.toCharArray());
                X509Certificate cert = (X509Certificate) ks.getCertificate(samlKeystoreAlias);
                return new Saml2X509Credential(privateKey, cert, Saml2X509Credential.Saml2X509CredentialType.SIGNING, Saml2X509Credential.Saml2X509CredentialType.DECRYPTION);
            }
        } catch (Exception e) {
            throw new IllegalStateException("Failed to load SAML signing credential from keystore", e);
        }
    }

    @Bean
    public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() {
        RelyingPartyRegistration.Builder builder =
                RelyingPartyRegistrations.fromMetadataLocation(samlMetadataUrl)
                        .registrationId("keycloak");

        if (spEntityId != null && !spEntityId.isBlank()) {
            builder.entityId(spEntityId);
        }
        if (spAcsUrl != null && !spAcsUrl.isBlank()) {
            builder.assertionConsumerServiceLocation(spAcsUrl);
        }

        builder.signingX509Credentials(c -> c.add(loadSigningCredential()));

        RelyingPartyRegistration reg = builder.build();
        return new InMemoryRelyingPartyRegistrationRepository(reg);
    }

    @Bean
    public SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler() {
        SavedRequestAwareAuthenticationSuccessHandler delegate = new SavedRequestAwareAuthenticationSuccessHandler();
        delegate.setDefaultTargetUrl("/landing");

        return new SavedRequestAwareAuthenticationSuccessHandler() {
            @Override
            public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, org.springframework.security.core.Authentication authentication) throws java.io.IOException, ServletException {
                if (authentication instanceof Saml2Authentication samlAuth) {
                    try {
                        UserDetails user = samlUserDetailsServiceImpl.loadUserDetails(samlAuth);
                        UsernamePasswordAuthenticationToken newAuth = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                        SecurityContextHolder.getContext().setAuthentication(newAuth);
                    } catch (Exception e) {
                        // ignore and proceed with original authentication
                    }
                }
                delegate.onAuthenticationSuccess(request, response, authentication);
            }
        };
    }

    @Bean
    public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler() {
        SimpleUrlAuthenticationFailureHandler handler = new SimpleUrlAuthenticationFailureHandler();
        handler.setUseForward(true);
        handler.setDefaultFailureUrl("/error");
        return handler;
    }

    @Bean
    public SimpleUrlLogoutSuccessHandler successLogoutHandler() {
        SimpleUrlLogoutSuccessHandler handler = new SimpleUrlLogoutSuccessHandler();
        handler.setDefaultTargetUrl("/");
        return handler;
    }

    @Bean
    public SecurityFilterChain samlSecurityFilterChain(HttpSecurity http,
                                                      RelyingPartyRegistrationRepository relyingPartyRegistrationRepository) throws Exception {
        // Use a small lambda-based RequestMatcher to avoid AntPathRequestMatcher dependency issues.
        http.securityMatcher(request -> {
            String path = request.getRequestURI();
            return path.startsWith("/saml2/") || path.startsWith("/login/") || path.startsWith("/saml2/service-provider-metadata/") || path.equals("/logout");
        });

        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/saml2/**", "/login/**", "/static/**", "/error").permitAll()
                .anyRequest().authenticated()
            )
            .saml2Login(saml2 -> saml2
                .relyingPartyRegistrationRepository(relyingPartyRegistrationRepository)
                .successHandler(successRedirectHandler())
                .failureHandler(authenticationFailureHandler())
            )
            .logout(logout -> logout
                .logoutSuccessHandler(successLogoutHandler())
            );

        return http.build();
    }
}
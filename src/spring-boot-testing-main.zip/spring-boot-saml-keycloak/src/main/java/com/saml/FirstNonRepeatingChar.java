package com.saml;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FirstNonRepeatingChar {
    public static char firstNonRepeatingChar(String input){
        Map<Character, Integer> charCount = new HashMap<>();
        for(int i = 0; i < input.length(); i++){
            charCount.put(input.charAt(i), charCount.getOrDefault(input.charAt(i), 0) + 1);
        }
        for(Map.Entry<Character, Integer> entry : charCount.entrySet()){
            // changed code: compare Integer values using equals to avoid incompatible Object vs int issues
            if (Integer.valueOf(1).equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return '\0'; // Return null character if no non-repeating character is found
    }
    public static char firstNonRepeatingCharV2(String input) {
    // collect counts with proper generics to avoid raw-Object issues
        Map<Integer, Integer> counts = input.chars()
            .boxed()
            .collect(
                Collectors.groupingBy(
                    Function.identity(),  Collectors.summingInt(i -> 1))
            );
        return counts.entrySet()
            .stream()
            .filter(e -> e.getValue() == 1)
            .map(Map.Entry::getKey)
            .findFirst()
            .map(i -> (char) i.intValue())
            .orElse('\0');
}
    public static void main(String[] args) {
        String input = "swiss";
        char result = firstNonRepeatingCharV2(input);
        if (result != '\0') {
            System.out.println("The first non-repeating character is: " + result);
        } else {
            System.out.println("No non-repeating character found.");
        }
    }
}
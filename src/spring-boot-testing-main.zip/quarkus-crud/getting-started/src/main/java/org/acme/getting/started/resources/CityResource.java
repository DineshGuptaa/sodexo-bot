package org.acme.getting.started.resources;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import org.acme.getting.started.entities.City;
import org.acme.getting.started.pages.PageRequest;
import org.acme.getting.started.services.CityService;
import org.jboss.resteasy.annotations.jaxrs.PathParam;

@Path("/cities")
@Produces(MediaType.APPLICATION_JSON)
public class CityResource {

	@Inject
	CityService cityService;

	@GET
	@Path("/count")
	@Transactional
	public long count() {
		return cityService.count();
	}

	@GET
	@Transactional
	public Response getAllPaged(@BeanParam PageRequest pageRequest) {
		return cityService.getAllPaged(pageRequest);
	}

	@GET
	@Path("{id}")
	@Transactional
	public Response getAllByStateId(@PathParam("id") Long id, @BeanParam PageRequest pageRequest) {
		return cityService.getAllByStateId(id, pageRequest);
	}

	@GET
	@Path("/find/{name}")
	@Transactional
	public Response getAllByCityName(@PathParam("name") String name, @BeanParam PageRequest pageRequest) {
		return cityService.getAllByCityName(name, pageRequest);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Transactional
	public Response persist(City city) {
		return cityService.persist(city);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{id}")
	@Transactional
	public Response update(@PathParam("id") Long id, City city) {
		return cityService.update(id, city);
	}

	@DELETE
	@Path("{id}")
	@Transactional
	public Response delete(@PathParam("id") Long id) {
		return cityService.delete(id);
	}

}

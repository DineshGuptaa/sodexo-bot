package org.acme.getting.started.resources;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam; // Corrected Import
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;

import org.acme.getting.started.entities.State;
import org.acme.getting.started.pages.PageRequest;
import org.acme.getting.started.services.StateService;

@Path("/states")
@Produces(MediaType.APPLICATION_JSON)
public class StateResource {

	@Context
	UriInfo uriInfo;

	@Inject
	StateService stateService;

	@GET
	@Path("/count")
	@Transactional
	public long count() {
		return stateService.count();
	}

	@GET
	@Transactional
	public Response getAllPaged(@BeanParam PageRequest pageRequest) {
		return stateService.getAllPaged(pageRequest);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Transactional
	public Response persist(State state) {
		return stateService.persist(state, uriInfo);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{id}")
	@Transactional
	public Response update(@PathParam("id") Long id, State state) {
		return stateService.update(id, state);
	}

	@DELETE
	@Path("{id}")
	@Transactional
	public Response delete(@PathParam("id") Long id) {
		return stateService.delete(id);
	}
}


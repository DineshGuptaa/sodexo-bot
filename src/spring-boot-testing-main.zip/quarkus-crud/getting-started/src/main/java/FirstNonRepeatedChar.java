import java.util.LinkedHashMap;
import java.util.Map;

public class FirstNonRepeatedChar {
  public static void main(String[] args){
    String word = "swiss";
    word.chars().mapToObj(c -> (char)c).collect(
        LinkedHashMap::new,(map, ch) -> map.put(ch, map.getOrDefault(ch, 0) + 1),
        Map::putAll
    ).entrySet().stream().filter(e ->e.getValue()==1).map(Map.Entry::getKey);
  }
}

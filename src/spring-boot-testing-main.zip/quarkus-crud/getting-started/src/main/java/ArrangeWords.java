import java.util.LinkedHashMap;

public class ArrangeWords {

  public static void main(String[] args){
    String gaveStr = "laptop mobile and desktop are not exempt";
    String[] str = gaveStr.split(" ");

    LinkedHashMap <String, Integer> map = new LinkedHashMap<>();
    for(String s : str){
      if(map.containsKey(s)){
        map.put(s, s.length());
      }else {
        map.put(s,1);
      }
    }

    for(String key : map.keySet()){
      map.get(key);
    }
  }
}

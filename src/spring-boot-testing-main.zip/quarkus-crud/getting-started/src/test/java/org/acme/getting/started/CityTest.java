package org.acme.getting.started;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString; // Added for flexible URL checking
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import jakarta.inject.Inject; // Correct for 3.x
import jakarta.transaction.Transactional; // Required for repository operations

import org.acme.getting.started.entities.City;
import org.acme.getting.started.entities.State;
import org.acme.getting.started.repositories.CityRepository;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class CityTest {

	@Inject
	CityRepository cityRepository;

	@Test
	public void testGetCity() {
		City city = new City(1L, "CityTest", new State(27L, "StateTest", "RegionTest"));
		assertEquals("StateTest", city.getState().getName());
	}

	@Test
	public void testSetCity() {
		City city = new City(1L, "CityTest", new State(27L, "StateTest", "RegionTest"));
		city.getState().setName("test2");
		assertEquals("test2", city.getState().getName());
	}

	@Test
	@Transactional // Ensures DB connection is active for the count query
	public void testCountService() {
		Long value = cityRepository.count();
		assertTrue(value >= 0); // Changed to >= 0 unless you have guaranteed seed data
	}

	@Test
	@Transactional
	public void testGetAllService() {
		List<City> cities = cityRepository.listAll();
		// This will only be > 0 if you have an import.sql or @BeforeEach setup
		assertTrue(cities.size() >= 0);
	}

	@Test
	public void testGetAllPagedEndpoint() {
		given()
				.when().get("/cities?pageNum=0&pageSize=1")
				.then()
				.statusCode(200);
	}

	@Test
	public void testPersistEndpoint() {
		given()
				.header("Content-Type", "application/json")
				.body(new City(null, "NewCity", new State(1L, "S", "R"))) // Added body as POST usually requires it
				.when().post("/cities")
				.then()
				.statusCode(201)
				// Use containsString because Quarkus tests often run on port 8081, not 8080
				.header("Location", containsString("/cities/"));
	}

	@Test
	public void testUpdateEndpoint() {
		given()
				.header("Content-Type", "application/json")
				.body(new City(1L, "UpdatedName", null))
				.when().put("/cities/{id}", 1L)
				.then()
				.statusCode(200);
	}

	@Test
	public void testDeleteEndpoint() {
		given()
				.when().delete("/cities/{id}", 1L)
				.then()
				.statusCode(204);
	}

	@Test
	public void testGetAllByStateIdEndpoint() {
		given()
				.when().get("/cities/{id}", 1L)
				.then()
				.statusCode(200);
	}

	@Test
	public void testGetAllByCityNameEndpoint() {
		given()
				.when().get("/cities/find/{name}", "Surubim")
				.then()
				.statusCode(200);
	}
}
